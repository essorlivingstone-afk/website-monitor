import { useState, useRef, useCallback, useEffect } from 'react';

export type MonitorStatus = 'idle' | 'running' | 'paused' | 'checking' | 'detected' | 'error';
export type DetectionState = 'waiting' | 'detected' | 'unknown';

export interface LogEntry {
  id: string;
  timestamp: Date;
  type: 'info' | 'success' | 'warning' | 'error' | 'check';
  message: string;
}

export interface NotificationEntry {
  id: string;
  timestamp: Date;
  type: string;
  message: string;
  acknowledged: boolean;
}

export interface MonitorConfig {
  targetUrl: string;
  waitingText: string;
  targetPhrases: string[];
}

export interface MonitorState {
  status: MonitorStatus;
  detectionState: DetectionState;
  lastChecked: Date | null;
  lastDetected: Date | null;
  checkCount: number;
  errorCount: number;
  consecutiveErrors: number;
  startTime: Date | null;
  logs: LogEntry[];
  notifications: NotificationEntry[];
  alarmActive: boolean;
  alarmEnabled: boolean;
  pushEnabled: boolean;
  currentPageText: string;
  detectedUrl: string;
  intervalSeconds: number;
  config: MonitorConfig;
}

export const DEFAULT_CONFIG: MonitorConfig = {
  targetUrl: 'https://biozium.com/public/bio-links/rusty-iron/',
  waitingText: 'will be updated in some hours, check later',
  targetPhrases: [
    'get here',
    'to get access',
    'get access',
    'please choose',
    'captcha',
    'choose to get',
  ],
};

const CORS_PROXIES = [
  'https://api.allorigins.win/raw?url=',
  'https://corsproxy.io/?',
  'https://api.codetabs.com/v1/proxy?quest=',
];

function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
}

// ────────────────────────────────────────────
// ALARM SYSTEM
// ────────────────────────────────────────────
let audioContext: AudioContext | null = null;
let alarmInterval: ReturnType<typeof setInterval> | null = null;
let activeOscillators: OscillatorNode[] = [];

function getAudioContext(): AudioContext {
  if (!audioContext || audioContext.state === 'closed') {
    audioContext = new AudioContext();
  }
  if (audioContext.state === 'suspended') {
    audioContext.resume();
  }
  return audioContext;
}

function playAlarmSound() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    const duration = 1.4;

    const compressor = ctx.createDynamicsCompressor();
    compressor.threshold.setValueAtTime(-10, now);
    compressor.knee.setValueAtTime(0, now);
    compressor.ratio.setValueAtTime(20, now);
    compressor.attack.setValueAtTime(0, now);
    compressor.release.setValueAtTime(0.05, now);
    compressor.connect(ctx.destination);

    // Layer 1: Rapid alternating siren
    const sirenGain = ctx.createGain();
    sirenGain.gain.setValueAtTime(0.35, now);
    sirenGain.gain.linearRampToValueAtTime(0, now + duration);
    sirenGain.connect(compressor);
    const siren = ctx.createOscillator();
    siren.type = 'sawtooth';
    const steps = 14;
    for (let i = 0; i < steps; i++) {
      siren.frequency.setValueAtTime(i % 2 === 0 ? 880 : 1320, now + (i * duration) / steps);
    }
    siren.connect(sirenGain);
    siren.start(now); siren.stop(now + duration);
    activeOscillators.push(siren);

    // Layer 2: High-pitched square beeps
    const beepGain = ctx.createGain();
    beepGain.connect(compressor);
    const beep = ctx.createOscillator();
    beep.type = 'square';
    beep.frequency.setValueAtTime(1760, now);
    const pulses = 10;
    for (let i = 0; i < pulses; i++) {
      const tOn = now + (i * duration) / pulses;
      const tOff = tOn + duration / pulses * 0.6;
      beepGain.gain.setValueAtTime(0.3, tOn);
      beepGain.gain.setValueAtTime(0, tOff);
    }
    beepGain.gain.setValueAtTime(0, now + duration);
    beep.connect(beepGain);
    beep.start(now); beep.stop(now + duration);
    activeOscillators.push(beep);

    // Layer 3: Low bass rumble
    const rumbleGain = ctx.createGain();
    rumbleGain.gain.setValueAtTime(0.4, now);
    rumbleGain.gain.linearRampToValueAtTime(0, now + duration);
    rumbleGain.connect(compressor);
    const rumble = ctx.createOscillator();
    rumble.type = 'sawtooth';
    rumble.frequency.setValueAtTime(110, now);
    for (let i = 0; i < 7; i++) {
      rumbleGain.gain.setValueAtTime(i % 2 === 0 ? 0.4 : 0.15, now + (i * duration) / 7);
    }
    rumble.connect(rumbleGain);
    rumble.start(now); rumble.stop(now + duration);
    activeOscillators.push(rumble);

    // Layer 4: Sweeping wail
    const wailGain = ctx.createGain();
    wailGain.gain.setValueAtTime(0.25, now);
    wailGain.gain.linearRampToValueAtTime(0, now + duration);
    wailGain.connect(compressor);
    const wail = ctx.createOscillator();
    wail.type = 'sawtooth';
    wail.frequency.setValueAtTime(600, now);
    wail.frequency.linearRampToValueAtTime(1800, now + duration * 0.5);
    wail.frequency.linearRampToValueAtTime(600, now + duration);
    wail.connect(wailGain);
    wail.start(now); wail.stop(now + duration);
    activeOscillators.push(wail);

    // Layer 5: Ultra-high ticks
    const tickGain = ctx.createGain();
    tickGain.connect(compressor);
    const tick = ctx.createOscillator();
    tick.type = 'square';
    tick.frequency.setValueAtTime(3520, now);
    const ticks = 20;
    for (let i = 0; i < ticks; i++) {
      const tOn = now + (i * duration) / ticks;
      tickGain.gain.setValueAtTime(0.2, tOn);
      tickGain.gain.setValueAtTime(0, tOn + 0.02);
    }
    tickGain.gain.setValueAtTime(0, now + duration);
    tick.connect(tickGain);
    tick.start(now); tick.stop(now + duration);
    activeOscillators.push(tick);

    setTimeout(() => {
      activeOscillators = activeOscillators.filter(
        o => o !== siren && o !== beep && o !== rumble && o !== wail && o !== tick
      );
    }, (duration + 0.5) * 1000);
  } catch (e) {
    console.error('Audio error:', e);
  }
}

function startRepeatingAlarm() {
  if (alarmInterval) return;
  playAlarmSound();
  alarmInterval = setInterval(playAlarmSound, 1600);
}

function stopRepeatingAlarm() {
  if (alarmInterval) {
    clearInterval(alarmInterval);
    alarmInterval = null;
  }
  activeOscillators.forEach(o => { try { o.stop(); } catch (_) { /* already stopped */ } });
  activeOscillators = [];
}

// ────────────────────────────────────────────
// BROWSER NOTIFICATIONS
// ────────────────────────────────────────────
async function sendBrowserNotification(title: string, body: string) {
  if ('Notification' in window && Notification.permission === 'granted') {
    try {
      new Notification(title, {
        body,
        tag: 'monitor-alert',
        requireInteraction: true,
      } as NotificationOptions);
    } catch (e) {
      console.error('Notification error:', e);
    }
  }
}

// ────────────────────────────────────────────
// FETCH
// ────────────────────────────────────────────
async function fetchPageContent(url: string, proxyIndex = 0): Promise<string> {
  if (proxyIndex >= CORS_PROXIES.length) {
    throw new Error('All CORS proxies failed');
  }
  const proxy = CORS_PROXIES[proxyIndex];
  const proxiedUrl = `${proxy}${encodeURIComponent(url)}`;
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);
    const response = await fetch(proxiedUrl, {
      signal: controller.signal,
      headers: { 'Accept': 'text/html,application/xhtml+xml' },
    });
    clearTimeout(timeout);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return await response.text();
  } catch (error) {
    console.warn(`Proxy ${proxyIndex} failed, trying next...`);
    return fetchPageContent(url, proxyIndex + 1);
  }
}

// ────────────────────────────────────────────
// ANALYZE
// ────────────────────────────────────────────
interface AnalysisResult {
  hasWaitingText: boolean;
  hasTargetText: boolean;
  extractedText: string;
  foundLink: string;
  matchedPhrase: string;
}

function analyzeContent(html: string, config: MonitorConfig): AnalysisResult {
  const tempDiv = document.createElement('div');
  tempDiv.innerHTML = html;
  const textContent = (tempDiv.textContent || tempDiv.innerText || '').toLowerCase();
  const rawLower = html.toLowerCase();

  // Check for waiting text
  const waitingLower = config.waitingText.toLowerCase().trim();
  const hasWaitingText = waitingLower
    ? (textContent.includes(waitingLower) || rawLower.includes(waitingLower))
    : false;

  // Check for any target phrase
  let hasTargetText = false;
  let matchedPhrase = '';
  for (const phrase of config.targetPhrases) {
    const p = phrase.toLowerCase().trim();
    if (p && (textContent.includes(p) || rawLower.includes(p))) {
      hasTargetText = true;
      matchedPhrase = phrase;
      break;
    }
  }

  // If waiting text is GONE and page has content → change detected
  const waitingTextGone = !hasWaitingText && textContent.trim().length > 10;
  const detected = hasTargetText || (waitingLower ? waitingTextGone : false);

  // Extract first meaningful link
  let foundLink = '';
  const allLinks = tempDiv.querySelectorAll('a[href]');
  for (const link of allLinks) {
    const href = link.getAttribute('href') || '';
    if (href && href !== '#' && !href.startsWith('javascript:') && !href.startsWith('mailto:')) {
      try { foundLink = new URL(href, config.targetUrl).href; } catch { foundLink = href; }
      break;
    }
  }
  if (!foundLink) {
    const linkRegex = /href\s*=\s*["']([^"'#][^"']*)["']/gi;
    const match = linkRegex.exec(html);
    if (match?.[1] && !match[1].startsWith('javascript:') && !match[1].startsWith('mailto:')) {
      try { foundLink = new URL(match[1], config.targetUrl).href; } catch { foundLink = match[1]; }
    }
  }

  // Build display text
  let extractedText = 'Page loaded successfully';
  if (hasWaitingText) {
    extractedText = config.waitingText || 'Still showing waiting message';
  } else if (matchedPhrase) {
    extractedText = matchedPhrase.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
  } else if (waitingTextGone && waitingLower) {
    const snippet = textContent.trim().slice(0, 120).replace(/\s+/g, ' ');
    extractedText = snippet ? `Changed: "${snippet}..."` : 'Page Changed!';
  }

  return { hasWaitingText, hasTargetText: detected, extractedText, foundLink, matchedPhrase };
}

// ────────────────────────────────────────────
// MAIN HOOK
// ────────────────────────────────────────────
export function useMonitor() {
  const [state, setState] = useState<MonitorState>({
    status: 'idle',
    detectionState: 'unknown',
    lastChecked: null,
    lastDetected: null,
    checkCount: 0,
    errorCount: 0,
    consecutiveErrors: 0,
    startTime: null,
    logs: [],
    notifications: [],
    alarmActive: false,
    alarmEnabled: true,
    pushEnabled: false,
    currentPageText: '',
    detectedUrl: '',
    intervalSeconds: 60,
    config: DEFAULT_CONFIG,
  });

  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const previousStateRef = useRef<DetectionState>('unknown');
  // Keep a ref to config so performCheck always reads the latest without stale closure
  const configRef = useRef<MonitorConfig>(DEFAULT_CONFIG);

  const addLog = useCallback((type: LogEntry['type'], message: string) => {
    const entry: LogEntry = { id: generateId(), timestamp: new Date(), type, message };
    setState(prev => ({ ...prev, logs: [entry, ...prev.logs].slice(0, 200) }));
  }, []);

  const addNotification = useCallback((type: string, message: string) => {
    const entry: NotificationEntry = { id: generateId(), timestamp: new Date(), type, message, acknowledged: false };
    setState(prev => ({ ...prev, notifications: [entry, ...prev.notifications].slice(0, 50) }));
  }, []);

  const performCheck = useCallback(async () => {
    const config = configRef.current;
    setState(prev => ({ ...prev, status: 'checking' }));
    addLog('check', `Checking ${config.targetUrl}...`);

    try {
      const html = await fetchPageContent(config.targetUrl);
      const { hasWaitingText, hasTargetText, extractedText, foundLink, matchedPhrase } = analyzeContent(html, config);

      const now = new Date();
      let newDetectionState: DetectionState;

      if (hasTargetText) {
        newDetectionState = 'detected';
      } else if (hasWaitingText) {
        newDetectionState = 'waiting';
      } else {
        newDetectionState = 'unknown';
      }

      setState(prev => {
        const isNewDetection = newDetectionState === 'detected' && previousStateRef.current !== 'detected';

        if (isNewDetection) {
          const msg = matchedPhrase
            ? `🚨 PAGE CHANGED! Found: "${matchedPhrase}"`
            : '🚨 PAGE CHANGED! Waiting text is GONE!';
          addLog('success', msg);
          addLog('success', `📄 Content: ${extractedText}`);
          if (foundLink) addLog('success', `🔗 Link found: ${foundLink}`);

          const notifMsg = matchedPhrase
            ? `Page changed! Found "${matchedPhrase}"`
            : 'Page changed! Waiting text removed!';
          addNotification('detection', `${notifMsg}${foundLink ? ` → ${foundLink}` : ''}`);
          sendBrowserNotification('🚨 PAGE CHANGED!', `${extractedText}${foundLink ? ` → ${foundLink}` : ''} — WAKE UP!`);

          if (prev.alarmEnabled) startRepeatingAlarm();
        } else if (newDetectionState === 'waiting') {
          addLog('info', 'Page still shows waiting message. Monitoring continues...');
        } else if (newDetectionState === 'detected' && previousStateRef.current === 'detected') {
          addLog('info', `Change still active. Content: ${extractedText}`);
        } else {
          addLog('info', `Page checked. State: ${extractedText}`);
        }

        previousStateRef.current = newDetectionState;

        return {
          ...prev,
          status: newDetectionState === 'detected' ? 'detected' : 'running',
          detectionState: newDetectionState,
          lastChecked: now,
          lastDetected: newDetectionState === 'detected' ? now : prev.lastDetected,
          checkCount: prev.checkCount + 1,
          consecutiveErrors: 0,
          currentPageText: extractedText,
          detectedUrl: foundLink || prev.detectedUrl,
          alarmActive: isNewDetection && prev.alarmEnabled ? true : prev.alarmActive,
        };
      });
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      addLog('error', `Check failed: ${errorMsg}`);
      setState(prev => ({
        ...prev,
        status: 'running',
        errorCount: prev.errorCount + 1,
        consecutiveErrors: prev.consecutiveErrors + 1,
        lastChecked: new Date(),
      }));
    }
  }, [addLog, addNotification]);

  const startMonitoring = useCallback(() => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    setState(prev => ({ ...prev, status: 'running', startTime: prev.startTime || new Date() }));
    addLog('info', `▶ Monitoring started → ${configRef.current.targetUrl}`);
    performCheck();
    intervalRef.current = setInterval(performCheck, state.intervalSeconds * 1000);
  }, [performCheck, addLog, state.intervalSeconds]);

  const pauseMonitoring = useCallback(() => {
    if (intervalRef.current) { clearInterval(intervalRef.current); intervalRef.current = null; }
    setState(prev => ({ ...prev, status: 'paused' }));
    addLog('warning', '⏸ Monitoring paused');
  }, [addLog]);

  const stopMonitoring = useCallback(() => {
    if (intervalRef.current) { clearInterval(intervalRef.current); intervalRef.current = null; }
    stopRepeatingAlarm();
    setState(prev => ({ ...prev, status: 'idle', alarmActive: false }));
    addLog('info', '⏹ Monitoring stopped');
  }, [addLog]);

  const dismissAlarm = useCallback(() => {
    stopRepeatingAlarm();
    setState(prev => ({ ...prev, alarmActive: false }));
    addLog('info', '🔕 Alarm dismissed');
  }, [addLog]);

  const testAlarm = useCallback(() => {
    playAlarmSound();
    addLog('info', "🔔 Test alarm triggered — this is what you'll hear!");
    sendBrowserNotification('Test Alert', 'Test notification from Page Monitor');
  }, [addLog]);

  const toggleAlarm = useCallback(() => {
    setState(prev => {
      if (prev.alarmEnabled) stopRepeatingAlarm();
      return { ...prev, alarmEnabled: !prev.alarmEnabled, alarmActive: !prev.alarmEnabled ? prev.alarmActive : false };
    });
  }, []);

  const requestPushPermission = useCallback(async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      setState(prev => ({ ...prev, pushEnabled: permission === 'granted' }));
      addLog(permission === 'granted' ? 'success' : 'warning',
        permission === 'granted' ? '✅ Push notifications enabled' : '⚠ Push notification permission denied');
    }
  }, [addLog]);

  const acknowledgeNotification = useCallback((id: string) => {
    setState(prev => ({
      ...prev,
      notifications: prev.notifications.map(n => n.id === id ? { ...n, acknowledged: true } : n),
    }));
  }, []);

  const clearLogs = useCallback(() => setState(prev => ({ ...prev, logs: [] })), []);

  const setIntervalSeconds = useCallback((seconds: number) => {
    setState(prev => ({ ...prev, intervalSeconds: seconds }));
  }, []);

  const setConfig = useCallback((newConfig: MonitorConfig) => {
    configRef.current = newConfig;
    setState(prev => ({ ...prev, config: newConfig }));
    addLog('info', `⚙️ Config updated → ${newConfig.targetUrl}`);
  }, [addLog]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      stopRepeatingAlarm();
    };
  }, []);

  // Sync config ref when state changes
  useEffect(() => {
    configRef.current = state.config;
  }, [state.config]);

  // Push permission check on mount
  useEffect(() => {
    if ('Notification' in window) {
      setState(prev => ({ ...prev, pushEnabled: Notification.permission === 'granted' }));
    }
  }, []);

  return {
    state,
    startMonitoring,
    pauseMonitoring,
    stopMonitoring,
    performCheck,
    dismissAlarm,
    testAlarm,
    toggleAlarm,
    requestPushPermission,
    acknowledgeNotification,
    clearLogs,
    setIntervalSeconds,
    setConfig,
  };
}
