import type { MonitorStatus } from '../hooks/useMonitor';

interface MonitorControlsProps {
  status: MonitorStatus;
  alarmEnabled: boolean;
  alarmActive: boolean;
  pushEnabled: boolean;
  intervalSeconds: number;
  onStart: () => void;
  onPause: () => void;
  onStop: () => void;
  onRefresh: () => void;
  onTestAlarm: () => void;
  onToggleAlarm: () => void;
  onDismissAlarm: () => void;
  onRequestPush: () => void;
  onSetInterval: (s: number) => void;
}

export function MonitorControls({
  status,
  alarmEnabled,
  alarmActive,
  pushEnabled,
  intervalSeconds,
  onStart,
  onPause,
  onStop,
  onRefresh,
  onTestAlarm,
  onToggleAlarm,
  onDismissAlarm,
  onRequestPush,
  onSetInterval,
}: MonitorControlsProps) {
  const isRunning = status === 'running' || status === 'checking' || status === 'detected';
  const isPaused = status === 'paused';

  return (
    <div className="glass-card rounded-2xl p-5 animate-slide-in">
      <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-4 flex items-center gap-2">
        <span className="text-emerald-glow">⚙️</span> Controls
      </h3>

      {/* Main Control Buttons */}
      <div className="grid grid-cols-2 gap-3 mb-5">
        {!isRunning && !isPaused ? (
          <button
            onClick={onStart}
            className="col-span-2 flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-emerald-500/20 text-emerald-400 font-semibold hover:bg-emerald-500/30 transition-all border border-emerald-500/30 hover:border-emerald-500/50 hover:shadow-lg hover:shadow-emerald-500/10"
          >
            <span>▶</span> Start Monitoring
          </button>
        ) : (
          <>
            {isRunning && (
              <button
                onClick={onPause}
                className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-amber-500/20 text-amber-400 font-semibold hover:bg-amber-500/30 transition-all border border-amber-500/30"
              >
                <span>⏸</span> Pause
              </button>
            )}
            {isPaused && (
              <button
                onClick={onStart}
                className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-emerald-500/20 text-emerald-400 font-semibold hover:bg-emerald-500/30 transition-all border border-emerald-500/30"
              >
                <span>▶</span> Resume
              </button>
            )}
            <button
              onClick={onStop}
              className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-red-500/20 text-red-400 font-semibold hover:bg-red-500/30 transition-all border border-red-500/30"
            >
              <span>⏹</span> Stop
            </button>
          </>
        )}

        <button
          onClick={onRefresh}
          disabled={status === 'checking'}
          className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-blue-500/20 text-blue-400 font-semibold hover:bg-blue-500/30 transition-all border border-blue-500/30 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          <span className={status === 'checking' ? 'animate-spin-slow inline-block' : ''}>🔄</span> Check Now
        </button>

        <button
          onClick={onTestAlarm}
          className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-purple-500/20 text-purple-400 font-semibold hover:bg-purple-500/30 transition-all border border-purple-500/30"
        >
          <span>🔔</span> Test Alarm
        </button>
      </div>

      {/* Alarm Dismiss */}
      {alarmActive && (
        <button
          onClick={onDismissAlarm}
          className="w-full mb-5 flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-red-500/30 text-red-300 font-bold hover:bg-red-500/40 transition-all border-2 border-red-500/50 animate-alarm-flash"
        >
          🔕 DISMISS ALARM
        </button>
      )}

      {/* Settings */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-sm text-slate-400">🔊 Alarm Sound</span>
          <button
            onClick={onToggleAlarm}
            className={`relative w-12 h-6 rounded-full transition-colors ${alarmEnabled ? 'bg-emerald-500' : 'bg-slate-600'}`}
          >
            <span
              className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${alarmEnabled ? 'translate-x-6' : ''}`}
            />
          </button>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm text-slate-400">📱 Push Notifications</span>
          {pushEnabled ? (
            <span className="text-xs text-emerald-400 font-medium bg-emerald-400/10 px-2 py-1 rounded-full">Enabled</span>
          ) : (
            <button
              onClick={onRequestPush}
              className="text-xs text-blue-400 font-medium bg-blue-400/10 px-3 py-1.5 rounded-full hover:bg-blue-400/20 transition-colors"
            >
              Enable
            </button>
          )}
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm text-slate-400">⏱ Check Interval</span>
          <select
            value={intervalSeconds}
            onChange={e => onSetInterval(Number(e.target.value))}
            className="bg-slate-700/50 text-slate-300 text-sm rounded-lg px-3 py-1.5 border border-slate-600/50 focus:outline-none focus:border-emerald-500/50"
          >
            <option value={15}>15s</option>
            <option value={30}>30s</option>
            <option value={60}>60s</option>
            <option value={120}>2min</option>
            <option value={300}>5min</option>
          </select>
        </div>
      </div>
    </div>
  );
}
