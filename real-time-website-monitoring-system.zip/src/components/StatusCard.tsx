import React from 'react';

interface StatusCardProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  glowColor?: string;
}

export function StatusCard({ title, icon, children, className = '', glowColor }: StatusCardProps) {
  return (
    <div
      className={`glass-card rounded-2xl p-5 animate-slide-in ${className}`}
      style={glowColor ? { borderColor: glowColor, boxShadow: `0 0 15px ${glowColor}22` } : {}}
    >
      <div className="flex items-center gap-2 mb-4">
        <span className="text-emerald-glow">{icon}</span>
        <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider">{title}</h3>
      </div>
      {children}
    </div>
  );
}
