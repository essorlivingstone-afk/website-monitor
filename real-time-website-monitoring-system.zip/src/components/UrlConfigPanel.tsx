import { useState, useEffect } from 'react';
import type { MonitorConfig } from '../hooks/useMonitor';
import { DEFAULT_CONFIG } from '../hooks/useMonitor';

interface UrlConfigPanelProps {
  config: MonitorConfig;
  isRunning: boolean;
  onSave: (config: MonitorConfig) => void;
}

function isValidUrl(url: string): boolean {
  try {
    const u = new URL(url);
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch {
    return false;
  }
}

export function UrlConfigPanel({ config, isRunning, onSave }: UrlConfigPanelProps) {
  const [targetUrl, setTargetUrl] = useState(config.targetUrl);
  const [waitingText, setWaitingText] = useState(config.waitingText);
  const [phrasesRaw, setPhrasesRaw] = useState(config.targetPhrases.join('\n'));
  const [urlError, setUrlError] = useState('');
  const [saved, setSaved] = useState(false);
  const [expanded, setExpanded] = useState(true);

  // Sync if config changes externally
  useEffect(() => {
    setTargetUrl(config.targetUrl);
    setWaitingText(config.waitingText);
    setPhrasesRaw(config.targetPhrases.join('\n'));
  }, [config]);

  function handleUrlChange(val: string) {
    setTargetUrl(val);
    if (val && !isValidUrl(val)) {
      setUrlError('Please enter a valid URL starting with http:// or https://');
    } else {
      setUrlError('');
    }
  }

  function handleSave() {
    if (!targetUrl.trim()) { setUrlError('URL is required'); return; }
    if (!isValidUrl(targetUrl.trim())) { setUrlError('Invalid URL — must start with http:// or https://'); return; }

    const phrases = phrasesRaw
      .split('\n')
      .map(p => p.trim())
      .filter(p => p.length > 0);

    onSave({
      targetUrl: targetUrl.trim(),
      waitingText: waitingText.trim(),
      targetPhrases: phrases,
    });

    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  function handleReset() {
    setTargetUrl(DEFAULT_CONFIG.targetUrl);
    setWaitingText(DEFAULT_CONFIG.waitingText);
    setPhrasesRaw(DEFAULT_CONFIG.targetPhrases.join('\n'));
    setUrlError('');
  }

  function handlePaste(e: React.ClipboardEvent<HTMLInputElement>) {
    // Auto-trim whitespace from pasted URLs
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').trim();
    setTargetUrl(pasted);
    if (pasted && !isValidUrl(pasted)) {
      setUrlError('Please enter a valid URL starting with http:// or https://');
    } else {
      setUrlError('');
    }
  }

  const isChanged =
    targetUrl !== config.targetUrl ||
    waitingText !== config.waitingText ||
    phrasesRaw !== config.targetPhrases.join('\n');

  return (
    <div className="glass-card rounded-2xl overflow-hidden animate-slide-in">
      {/* Header / toggle */}
      <button
        className="w-full flex items-center justify-between px-5 py-4 hover:bg-white/5 transition-colors"
        onClick={() => setExpanded(e => !e)}
      >
        <div className="flex items-center gap-2">
          <span className="text-emerald-glow text-lg">🔗</span>
          <span className="text-sm font-semibold text-slate-300 uppercase tracking-wider">Monitor Target</span>
          {isChanged && (
            <span className="text-xs bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-full px-2 py-0.5">
              Unsaved
            </span>
          )}
        </div>
        <span className={`text-slate-400 transition-transform duration-200 ${expanded ? 'rotate-180' : ''}`}>▼</span>
      </button>

      {expanded && (
        <div className="px-5 pb-5 space-y-4 border-t border-slate-700/40">
          {/* URL Input */}
          <div className="pt-4">
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Page URL to Monitor <span className="text-red-400">*</span>
            </label>
            <div className="relative">
              <input
                type="url"
                value={targetUrl}
                onChange={e => handleUrlChange(e.target.value)}
                onPaste={handlePaste}
                placeholder="https://example.com/page-to-watch"
                disabled={isRunning}
                className={`w-full bg-slate-900/60 text-slate-100 placeholder-slate-600 rounded-xl px-4 py-3 text-sm border transition-colors focus:outline-none pr-10
                  ${urlError
                    ? 'border-red-500/70 focus:border-red-500'
                    : isValidUrl(targetUrl)
                    ? 'border-emerald-500/40 focus:border-emerald-500/70'
                    : 'border-slate-600/50 focus:border-emerald-500/50'}
                  ${isRunning ? 'opacity-50 cursor-not-allowed' : ''}`}
              />
              {isValidUrl(targetUrl) && (
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-emerald-400 text-sm">✓</span>
              )}
            </div>
            {urlError && (
              <p className="text-xs text-red-400 mt-1.5 flex items-center gap-1">
                <span>⚠</span> {urlError}
              </p>
            )}
            {isRunning && (
              <p className="text-xs text-amber-400/70 mt-1.5">⏸ Stop monitoring before changing the URL</p>
            )}
            {/* Quick paste tip */}
            <p className="text-xs text-slate-600 mt-1.5">Paste any URL — whitespace is trimmed automatically</p>
          </div>

          {/* Waiting / Before Text */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
              Text That Means "Still Waiting"
            </label>
            <input
              type="text"
              value={waitingText}
              onChange={e => setWaitingText(e.target.value)}
              placeholder="e.g. will be updated in some hours, check later"
              disabled={isRunning}
              className={`w-full bg-slate-900/60 text-slate-100 placeholder-slate-600 rounded-xl px-4 py-3 text-sm border border-slate-600/50 focus:border-amber-500/50 focus:outline-none transition-colors ${isRunning ? 'opacity-50 cursor-not-allowed' : ''}`}
            />
            <p className="text-xs text-slate-600 mt-1">
              When this text disappears from the page, the alarm triggers. Leave blank to rely only on target phrases.
            </p>
          </div>

          {/* Target Phrases */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
              Trigger Phrases <span className="text-slate-500 normal-case font-normal">(one per line)</span>
            </label>
            <textarea
              value={phrasesRaw}
              onChange={e => setPhrasesRaw(e.target.value)}
              rows={4}
              placeholder={"get here\nto get access\nplease choose"}
              disabled={isRunning}
              className={`w-full bg-slate-900/60 text-slate-100 placeholder-slate-600 rounded-xl px-4 py-3 text-sm border border-slate-600/50 focus:border-blue-500/50 focus:outline-none transition-colors resize-none font-mono ${isRunning ? 'opacity-50 cursor-not-allowed' : ''}`}
            />
            <p className="text-xs text-slate-600 mt-1">
              If any of these phrases appear on the page, the alarm triggers immediately.
            </p>
          </div>

          {/* Preview of current active config */}
          {!isChanged && (
            <div className="bg-slate-800/40 rounded-xl p-3 text-xs space-y-1.5 border border-slate-700/30">
              <div className="text-slate-500 font-semibold uppercase tracking-wider mb-1">Active Config</div>
              <div className="flex gap-2">
                <span className="text-slate-500 shrink-0">URL:</span>
                <a href={config.targetUrl} target="_blank" rel="noopener noreferrer"
                  className="text-blue-400 hover:text-blue-300 truncate underline underline-offset-2">
                  {config.targetUrl}
                </a>
              </div>
              <div className="flex gap-2">
                <span className="text-slate-500 shrink-0">Waiting:</span>
                <span className="text-amber-300/80 italic truncate">
                  {config.waitingText ? `"${config.waitingText}"` : '(none)'}
                </span>
              </div>
              <div className="flex gap-2">
                <span className="text-slate-500 shrink-0">Phrases:</span>
                <span className="text-emerald-300/80">{config.targetPhrases.length} configured</span>
              </div>
            </div>
          )}

          {/* Action buttons */}
          <div className="flex gap-2 pt-1">
            <button
              onClick={handleSave}
              disabled={isRunning || !!urlError || !targetUrl.trim() || !isChanged}
              className={`flex-1 py-2.5 px-4 rounded-xl font-semibold text-sm transition-all
                ${saved
                  ? 'bg-emerald-500/30 text-emerald-400 border border-emerald-500/40'
                  : isChanged && !urlError && targetUrl.trim()
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/30'
                  : 'bg-slate-700/30 text-slate-600 border border-slate-700/30 cursor-not-allowed'}`}
            >
              {saved ? '✅ Saved!' : '💾 Save Config'}
            </button>
            <button
              onClick={handleReset}
              disabled={isRunning}
              className="py-2.5 px-4 rounded-xl font-semibold text-sm text-slate-400 bg-slate-700/30 border border-slate-600/30 hover:bg-slate-700/50 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              title="Reset to default (Rusty Iron)"
            >
              ↺ Default
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
