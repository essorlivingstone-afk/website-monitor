import { PulsingDot } from './PulsingDot';
import type { MonitorStatus } from '../hooks/useMonitor';

interface HeaderProps {
  status: MonitorStatus;
}

export function Header({ status }: HeaderProps) {
  const statusColor = status === 'detected' ? 'green' : status === 'running' || status === 'checking' ? 'blue' : status === 'error' ? 'red' : 'gray';
  const statusText = status === 'detected' ? 'Target Detected!' : status === 'running' ? 'Monitoring Active' : status === 'checking' ? 'Checking...' : status === 'paused' ? 'Paused' : status === 'error' ? 'Error' : 'Idle';

  return (
    <header className="glass-card border-b border-slate-700/50 px-4 sm:px-6 py-4">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-xl sm:text-2xl shadow-lg shadow-emerald-500/20">
              🔍
            </div>
            {status !== 'idle' && (
              <div className="absolute -top-1 -right-1">
                <PulsingDot color={statusColor as any} size="sm" />
              </div>
            )}
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Rusty Iron <span className="text-emerald-glow">Monitor</span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-400">Real-Time Website Change Detection</p>
          </div>
        </div>
        <div className="flex items-center gap-2 glass-card rounded-full px-4 py-2">
          <PulsingDot color={statusColor as any} size="sm" pulse={status === 'running' || status === 'checking'} />
          <span className="text-sm font-medium text-slate-300">{statusText}</span>
        </div>
      </div>
    </header>
  );
}
