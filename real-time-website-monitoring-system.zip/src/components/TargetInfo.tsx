import type { MonitorConfig } from '../hooks/useMonitor';

interface TargetInfoProps {
  config: MonitorConfig;
}

export function TargetInfo({ config }: TargetInfoProps) {
  return (
    <div className="glass-card rounded-2xl p-5 animate-slide-in">
      <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-4 flex items-center gap-2">
        <span className="text-emerald-glow">🎯</span> Detection Rules
      </h3>

      <div className="space-y-3 text-xs">
        <div className="bg-slate-800/30 rounded-xl p-3">
          <div className="text-slate-500 font-semibold uppercase tracking-wider mb-1">Detection Logic</div>
          <ol className="text-slate-400 list-decimal list-inside space-y-1">
            <li>Fetch page via CORS proxy</li>
            <li>Check if <span className="text-red-400">waiting text</span> is gone</li>
            <li>Check for any <span className="text-blue-400">trigger phrase</span></li>
            <li>Either condition → <span className="text-emerald-400 font-bold">ALARM!</span></li>
          </ol>
        </div>

        <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-3">
          <div className="text-red-400/80 font-semibold mb-1">⏳ Waiting Text</div>
          <p className="text-red-300/70 italic break-words leading-relaxed">
            {config.waitingText ? `"${config.waitingText}"` : '(not set — using phrases only)'}
          </p>
        </div>

        <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-3">
          <div className="text-blue-400/80 font-semibold mb-1.5">🎯 Trigger Phrases</div>
          {config.targetPhrases.length === 0 ? (
            <p className="text-slate-500 italic">No phrases configured</p>
          ) : (
            <div className="flex flex-wrap gap-1.5">
              {config.targetPhrases.map((p, i) => (
                <span key={i} className="bg-blue-500/20 text-blue-300 rounded-lg px-2 py-0.5 font-mono">
                  {p}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
