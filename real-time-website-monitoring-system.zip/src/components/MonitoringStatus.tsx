import { PulsingDot } from './PulsingDot';
import { StatusCard } from './StatusCard';
import type { MonitorStatus, DetectionState } from '../hooks/useMonitor';

interface MonitoringStatusProps {
  status: MonitorStatus;
  detectionState: DetectionState;
  lastChecked: Date | null;
  lastDetected: Date | null;
  checkCount: number;
  errorCount: number;
  startTime: Date | null;
  currentPageText: string;
  detectedUrl: string;
}

function formatTime(date: Date | null): string {
  if (!date) return 'Never';
  return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function formatDuration(start: Date | null): string {
  if (!start) return '—';
  const diff = Math.floor((Date.now() - start.getTime()) / 1000);
  const hours = Math.floor(diff / 3600);
  const mins = Math.floor((diff % 3600) / 60);
  const secs = diff % 60;
  if (hours > 0) return `${hours}h ${mins}m ${secs}s`;
  if (mins > 0) return `${mins}m ${secs}s`;
  return `${secs}s`;
}

export function MonitoringStatus({
  status,
  detectionState,
  lastChecked,
  lastDetected,
  checkCount,
  errorCount,
  startTime,
  currentPageText,
  detectedUrl,
}: MonitoringStatusProps) {
  const getDetectionIcon = () => {
    if (detectionState === 'detected') return '🎯';
    if (detectionState === 'waiting') return '⏳';
    return '❓';
  };

  const getDetectionColor = (): 'green' | 'red' | 'yellow' => {
    if (detectionState === 'detected') return 'green';
    if (detectionState === 'waiting') return 'red';
    return 'yellow';
  };

  const getDetectionText = () => {
    if (detectionState === 'detected') return 'PAGE CHANGED!';
    if (detectionState === 'waiting') return 'Waiting for change...';
    return 'Unknown state';
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {/* Monitoring Status */}
      <StatusCard title="Monitoring Status" icon="📡">
        <div className="flex items-center gap-3 mb-3">
          <PulsingDot
            color={status === 'running' || status === 'checking' ? 'blue' : status === 'detected' ? 'green' : status === 'paused' ? 'yellow' : 'gray'}
            size="lg"
            pulse={status === 'running' || status === 'checking'}
          />
          <div>
            <div className="text-lg font-bold text-white capitalize">{status}</div>
            <div className="text-xs text-slate-400">Uptime: {formatDuration(startTime)}</div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="bg-slate-800/50 rounded-lg p-2 text-center">
            <div className="text-slate-400">Checks</div>
            <div className="text-lg font-bold text-white">{checkCount}</div>
          </div>
          <div className="bg-slate-800/50 rounded-lg p-2 text-center">
            <div className="text-slate-400">Errors</div>
            <div className="text-lg font-bold text-red-400">{errorCount}</div>
          </div>
        </div>
      </StatusCard>

      {/* Detection Status */}
      <StatusCard
        title="Detection Status"
        icon={getDetectionIcon()}
        glowColor={detectionState === 'detected' ? '#00ff99' : undefined}
      >
        <div className="flex items-center gap-3 mb-3">
          <PulsingDot color={getDetectionColor()} size="lg" pulse={detectionState === 'detected'} />
          <div>
            <div className={`text-lg font-bold ${detectionState === 'detected' ? 'text-emerald-glow' : 'text-white'}`}>
              {getDetectionText()}
            </div>
            <div className="text-xs text-slate-400">
              {detectionState === 'detected' ? 'Change detected!' : 'Monitoring for page change'}
            </div>
          </div>
        </div>

        {detectionState === 'detected' && (
          <div className="space-y-2">
            <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-3 text-center">
              <div className="text-emerald-400 font-bold text-sm">🎉 Page has changed!</div>
              <div className="text-xs text-emerald-300/70 mt-1">Detected at {formatTime(lastDetected)}</div>
              <div className="text-xs text-emerald-200 mt-1 font-medium">{currentPageText}</div>
            </div>
            {detectedUrl && (
              <div className="bg-blue-500/10 border border-blue-400/30 rounded-lg p-3">
                <div className="text-xs text-blue-300/70 mb-1 font-semibold">🔗 Link found:</div>
                <a
                  href={detectedUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-400 hover:text-blue-300 text-xs font-mono break-all underline"
                >
                  {detectedUrl}
                </a>
              </div>
            )}
          </div>
        )}

        {detectionState === 'waiting' && (
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3 text-center">
            <div className="text-amber-400 text-sm">Still showing waiting message</div>
          </div>
        )}
      </StatusCard>

      {/* Current Page State */}
      <StatusCard title="Page State" icon="🌐">
        <div className="mb-3">
          <div className="text-xs text-slate-400 mb-1">Currently Displaying:</div>
          <div className={`text-sm font-semibold p-3 rounded-lg ${
            detectionState === 'detected'
              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
              : detectionState === 'waiting'
              ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
              : 'bg-slate-700/50 text-slate-300 border border-slate-600/30'
          }`}>
            {currentPageText || 'Not checked yet'}
          </div>
        </div>
        <div className="space-y-2 text-xs">
          <div className="flex justify-between text-slate-400">
            <span>Last Checked:</span>
            <span className="text-slate-300">{formatTime(lastChecked)}</span>
          </div>
          <div className="flex justify-between text-slate-400">
            <span>Target URL:</span>
            <a
              href="https://biozium.com/public/bio-links/rusty-iron/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-400 hover:text-blue-300 truncate ml-2 max-w-[150px]"
            >
              biozium.com/...rusty-iron/
            </a>
          </div>
          {detectedUrl && (
            <div className="pt-2 mt-2 border-t border-slate-700/50">
              <div className="text-slate-400 text-xs mb-1">🔗 Detected Link:</div>
              <a
                href={detectedUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-400 hover:text-blue-300 text-xs font-mono break-all underline"
              >
                {detectedUrl}
              </a>
            </div>
          )}
        </div>
      </StatusCard>
    </div>
  );
}
