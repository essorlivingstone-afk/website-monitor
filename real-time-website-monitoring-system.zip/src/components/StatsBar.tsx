import { useState, useEffect } from 'react';
import type { MonitorStatus } from '../hooks/useMonitor';

interface StatsBarProps {
  checkCount: number;
  errorCount: number;
  startTime: Date | null;
  status: MonitorStatus;
  consecutiveErrors: number;
}

function formatUptime(start: Date | null): string {
  if (!start) return '00:00:00';
  const diff = Math.floor((Date.now() - start.getTime()) / 1000);
  const h = Math.floor(diff / 3600).toString().padStart(2, '0');
  const m = Math.floor((diff % 3600) / 60).toString().padStart(2, '0');
  const s = (diff % 60).toString().padStart(2, '0');
  return `${h}:${m}:${s}`;
}

export function StatsBar({ checkCount, errorCount, startTime, status, consecutiveErrors }: StatsBarProps) {
  const [uptime, setUptime] = useState('00:00:00');

  useEffect(() => {
    if (status === 'idle') {
      setUptime('00:00:00');
      return;
    }
    const timer = setInterval(() => {
      setUptime(formatUptime(startTime));
    }, 1000);
    return () => clearInterval(timer);
  }, [startTime, status]);

  const successRate = checkCount > 0 ? (((checkCount - errorCount) / checkCount) * 100).toFixed(1) : '0.0';

  return (
    <div className="glass-card rounded-2xl p-4 animate-slide-in">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="text-center">
          <div className="text-xs text-slate-400 mb-1">Uptime</div>
          <div className="text-lg sm:text-xl font-bold font-mono text-emerald-glow">{uptime}</div>
        </div>
        <div className="text-center">
          <div className="text-xs text-slate-400 mb-1">Total Checks</div>
          <div className="text-lg sm:text-xl font-bold text-white">{checkCount}</div>
        </div>
        <div className="text-center">
          <div className="text-xs text-slate-400 mb-1">Success Rate</div>
          <div className={`text-lg sm:text-xl font-bold ${parseFloat(successRate) >= 90 ? 'text-emerald-400' : parseFloat(successRate) >= 70 ? 'text-amber-400' : 'text-red-400'}`}>
            {successRate}%
          </div>
        </div>
        <div className="text-center">
          <div className="text-xs text-slate-400 mb-1">Errors</div>
          <div className={`text-lg sm:text-xl font-bold ${consecutiveErrors > 0 ? 'text-red-400' : 'text-slate-300'}`}>
            {errorCount}
            {consecutiveErrors > 2 && (
              <span className="text-xs text-red-400 block">({consecutiveErrors} consecutive)</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
