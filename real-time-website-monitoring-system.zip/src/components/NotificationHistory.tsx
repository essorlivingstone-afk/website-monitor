import type { NotificationEntry } from '../hooks/useMonitor';

interface NotificationHistoryProps {
  notifications: NotificationEntry[];
  onAcknowledge: (id: string) => void;
}

function formatNotifTime(date: Date): string {
  return date.toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
}

export function NotificationHistory({ notifications, onAcknowledge }: NotificationHistoryProps) {
  return (
    <div className="glass-card rounded-2xl p-5 animate-slide-in">
      <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-4 flex items-center gap-2">
        <span className="text-emerald-glow">🔔</span> Notification History
      </h3>

      <div className="h-64 sm:h-80 overflow-y-auto scrollbar-thin space-y-2">
        {notifications.length === 0 ? (
          <div className="text-slate-500 text-center py-8">
            <div className="text-2xl mb-2">🔕</div>
            No notifications yet.
          </div>
        ) : (
          notifications.map(notif => (
            <div
              key={notif.id}
              className={`rounded-xl p-3 border transition-all ${
                notif.acknowledged
                  ? 'bg-slate-800/30 border-slate-700/30 opacity-60'
                  : 'bg-emerald-500/10 border-emerald-500/30 shadow-lg shadow-emerald-500/5'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-white">{notif.message}</div>
                  <div className="text-xs text-slate-400 mt-1">{formatNotifTime(notif.timestamp)}</div>
                </div>
                {!notif.acknowledged && (
                  <button
                    onClick={() => onAcknowledge(notif.id)}
                    className="text-xs text-emerald-400 bg-emerald-400/10 px-2 py-1 rounded-lg hover:bg-emerald-400/20 transition-colors shrink-0"
                  >
                    Dismiss
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
