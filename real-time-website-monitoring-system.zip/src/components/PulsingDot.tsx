interface PulsingDotProps {
  color: 'green' | 'red' | 'yellow' | 'blue' | 'gray';
  size?: 'sm' | 'md' | 'lg';
  pulse?: boolean;
}

const colorMap = {
  green: { bg: 'bg-emerald-400', ring: 'ring-emerald-400/30', shadow: 'shadow-emerald-400/50' },
  red: { bg: 'bg-red-400', ring: 'ring-red-400/30', shadow: 'shadow-red-400/50' },
  yellow: { bg: 'bg-amber-400', ring: 'ring-amber-400/30', shadow: 'shadow-amber-400/50' },
  blue: { bg: 'bg-blue-400', ring: 'ring-blue-400/30', shadow: 'shadow-blue-400/50' },
  gray: { bg: 'bg-slate-500', ring: 'ring-slate-500/30', shadow: 'shadow-slate-500/50' },
};

const sizeMap = {
  sm: 'w-2.5 h-2.5',
  md: 'w-3.5 h-3.5',
  lg: 'w-5 h-5',
};

export function PulsingDot({ color, size = 'md', pulse = true }: PulsingDotProps) {
  const c = colorMap[color];
  const s = sizeMap[size];

  return (
    <span className="relative inline-flex">
      {pulse && (
        <span className={`absolute inline-flex h-full w-full rounded-full ${c.bg} opacity-40 animate-ping`} />
      )}
      <span className={`relative inline-flex rounded-full ${s} ${c.bg} ring-2 ${c.ring} shadow-lg ${c.shadow}`} />
    </span>
  );
}
