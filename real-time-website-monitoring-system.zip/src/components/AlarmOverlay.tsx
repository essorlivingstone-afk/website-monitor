import { useState, useEffect } from 'react';

interface AlarmOverlayProps {
  active: boolean;
  detectedUrl: string;
  currentPageText: string;
  monitoredUrl: string;
  onDismiss: () => void;
}

export function AlarmOverlay({ active, detectedUrl, currentPageText, monitoredUrl, onDismiss }: AlarmOverlayProps) {
  const [flash, setFlash] = useState(false);

  // Rapid flashing effect
  useEffect(() => {
    if (!active) return;
    const timer = setInterval(() => setFlash(f => !f), 300);
    return () => clearInterval(timer);
  }, [active]);

  if (!active) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 transition-colors duration-200"
      style={{
        backgroundColor: flash
          ? 'rgba(239, 68, 68, 0.35)'
          : 'rgba(0, 0, 0, 0.8)',
      }}
    >
      {/* Pulsing border rings */}
      <div className="absolute inset-4 sm:inset-10 border-4 border-red-500/50 rounded-3xl animate-ping pointer-events-none" />
      <div className="absolute inset-8 sm:inset-16 border-2 border-amber-500/40 rounded-3xl animate-ping pointer-events-none" style={{ animationDelay: '0.3s' }} />

      <div className="relative bg-slate-900/98 border-4 border-red-500 rounded-3xl p-6 sm:p-10 max-w-lg w-full text-center shadow-2xl shadow-red-500/40 animate-slide-in">
        {/* Flashing top bar */}
        <div
          className="absolute top-0 left-0 right-0 h-2 rounded-t-3xl transition-colors duration-150"
          style={{ backgroundColor: flash ? '#ef4444' : '#f59e0b' }}
        />

        {/* Icon */}
        <div className="mb-5 relative">
          <span className="text-7xl sm:text-8xl block animate-bounce">🚨</span>
        </div>

        {/* Title */}
        <h2
          className="text-3xl sm:text-4xl font-black mb-2 transition-colors duration-300"
          style={{ color: flash ? '#ef4444' : '#f59e0b' }}
        >
          ⚠️ WAKE UP! ⚠️
        </h2>
        <h3 className="text-xl sm:text-2xl font-bold text-white mb-4">
          TARGET CHANGE DETECTED!
        </h3>

        {/* Detection info */}
        <div className="bg-emerald-500/20 border-2 border-emerald-500/50 rounded-2xl p-4 mb-4 animate-pulse-glow">
          <div className="text-xs text-emerald-300/70 uppercase tracking-wider mb-1">Page now shows</div>
          <span className="text-xl sm:text-2xl font-black text-emerald-glow break-words">
            {currentPageText || 'New Content Detected!'}
          </span>
        </div>

        {/* Detected URL - THE KEY NEW FEATURE */}
        {detectedUrl && (
          <div className="bg-blue-500/15 border-2 border-blue-400/40 rounded-2xl p-4 mb-4">
            <div className="text-xs text-blue-300/70 uppercase tracking-wider mb-2 font-bold">
              🔗 "Get Here" links to:
            </div>
            <a
              href={detectedUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-400 hover:text-blue-300 text-sm sm:text-base font-mono break-all underline underline-offset-4 decoration-blue-400/50 hover:decoration-blue-300"
            >
              {detectedUrl}
            </a>
            <a
              href={detectedUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="block mt-3 py-3 px-6 bg-blue-500 hover:bg-blue-400 text-white font-bold rounded-xl transition-colors shadow-lg shadow-blue-500/30 text-lg"
            >
              🔗 OPEN THE LINK
            </a>
          </div>
        )}

        {!detectedUrl && (
          <p className="text-sm text-slate-400 mb-4">
            The waiting text has been replaced. The update is live!
          </p>
        )}

        {/* Action buttons */}
        <div className="space-y-3">
          <button
            onClick={onDismiss}
            className="w-full py-4 px-6 bg-red-600 hover:bg-red-700 text-white font-black rounded-xl transition-colors shadow-lg shadow-red-600/30 text-xl tracking-wide"
          >
            🔕 STOP ALARM
          </button>
          <a
            href={monitoredUrl || detectedUrl || '#'}
            target="_blank"
            rel="noopener noreferrer"
            className="block py-3 px-6 bg-emerald-500 hover:bg-emerald-400 text-white font-bold rounded-xl transition-colors shadow-lg shadow-emerald-500/30"
          >
            🌐 VISIT MONITORED PAGE
          </a>
        </div>

        {/* Volume warning */}
        <p className="text-xs text-red-400/60 mt-4 animate-pulse">
          🔊 ALARM WILL KEEP RINGING UNTIL YOU CLICK "STOP ALARM" 🔊
        </p>
      </div>
    </div>
  );
}
