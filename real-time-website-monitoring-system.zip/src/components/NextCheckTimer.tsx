import { useState, useEffect } from 'react';
import type { MonitorStatus } from '../hooks/useMonitor';

interface NextCheckTimerProps {
  lastChecked: Date | null;
  intervalSeconds: number;
  status: MonitorStatus;
}

export function NextCheckTimer({ lastChecked, intervalSeconds, status }: NextCheckTimerProps) {
  const [secondsLeft, setSecondsLeft] = useState(intervalSeconds);

  useEffect(() => {
    if (status !== 'running' && status !== 'detected') {
      setSecondsLeft(intervalSeconds);
      return;
    }

    const timer = setInterval(() => {
      if (!lastChecked) {
        setSecondsLeft(intervalSeconds);
        return;
      }
      const elapsed = Math.floor((Date.now() - lastChecked.getTime()) / 1000);
      const remaining = Math.max(0, intervalSeconds - elapsed);
      setSecondsLeft(remaining);
    }, 500);

    return () => clearInterval(timer);
  }, [lastChecked, intervalSeconds, status]);

  const isActive = status === 'running' || status === 'detected';
  const progress = isActive ? ((intervalSeconds - secondsLeft) / intervalSeconds) * 100 : 0;

  return (
    <div className="glass-card rounded-2xl p-5 animate-slide-in">
      <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-4 flex items-center gap-2">
        <span className="text-emerald-glow">⏱</span> Next Check
      </h3>

      <div className="text-center mb-4">
        <div className={`text-4xl font-bold font-mono ${isActive ? 'text-white' : 'text-slate-500'}`}>
          {isActive ? `${secondsLeft}s` : '—'}
        </div>
        <div className="text-xs text-slate-400 mt-1">
          {isActive ? 'until next check' : status === 'paused' ? 'Paused' : 'Not running'}
        </div>
      </div>

      {/* Progress bar */}
      <div className="w-full bg-slate-800/50 rounded-full h-2 overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-500 ease-linear bg-gradient-to-r from-emerald-500 to-emerald-400"
          style={{ width: `${progress}%` }}
        />
      </div>

      <div className="flex justify-between text-xs text-slate-500 mt-2">
        <span>0s</span>
        <span>{intervalSeconds}s</span>
      </div>
    </div>
  );
}
