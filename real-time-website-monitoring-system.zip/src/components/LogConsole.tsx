import { useRef, useEffect } from 'react';
import type { LogEntry } from '../hooks/useMonitor';

interface LogConsoleProps {
  logs: LogEntry[];
  onClear: () => void;
}

const typeStyles: Record<string, string> = {
  info: 'text-blue-400',
  success: 'text-emerald-400',
  warning: 'text-amber-400',
  error: 'text-red-400',
  check: 'text-slate-400',
};

const typeIcons: Record<string, string> = {
  info: 'ℹ️',
  success: '✅',
  warning: '⚠️',
  error: '❌',
  check: '🔍',
};

function formatLogTime(date: Date): string {
  return date.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  });
}

export function LogConsole({ logs, onClear }: LogConsoleProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = 0;
    }
  }, [logs.length]);

  return (
    <div className="glass-card rounded-2xl p-5 animate-slide-in">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-2">
          <span className="text-emerald-glow">📋</span> System Logs
        </h3>
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500">{logs.length} entries</span>
          <button
            onClick={onClear}
            className="text-xs text-slate-400 hover:text-slate-300 bg-slate-700/50 px-3 py-1 rounded-lg transition-colors"
          >
            Clear
          </button>
        </div>
      </div>

      <div
        ref={scrollRef}
        className="h-64 sm:h-80 overflow-y-auto scrollbar-thin rounded-xl bg-slate-900/60 p-3 font-mono text-xs space-y-1"
      >
        {logs.length === 0 ? (
          <div className="text-slate-500 text-center py-8">
            <div className="text-2xl mb-2">📭</div>
            No logs yet. Start monitoring to see activity.
          </div>
        ) : (
          logs.map(log => (
            <div key={log.id} className="flex items-start gap-2 hover:bg-slate-800/30 rounded px-2 py-1 transition-colors">
              <span className="text-slate-600 shrink-0 select-none">[{formatLogTime(log.timestamp)}]</span>
              <span className="shrink-0">{typeIcons[log.type]}</span>
              <span className={typeStyles[log.type]}>{log.message}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
