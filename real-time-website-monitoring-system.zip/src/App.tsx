import { useState, useEffect } from 'react';
import { Toaster, toast } from 'react-hot-toast';
import { useMonitor } from './hooks/useMonitor';
import { Header } from './components/Header';
import { MonitoringStatus } from './components/MonitoringStatus';
import { MonitorControls } from './components/MonitorControls';
import { LogConsole } from './components/LogConsole';
import { NotificationHistory } from './components/NotificationHistory';
import { AlarmOverlay } from './components/AlarmOverlay';
import { TargetInfo } from './components/TargetInfo';
import { NextCheckTimer } from './components/NextCheckTimer';
import { StatsBar } from './components/StatsBar';
import { UrlConfigPanel } from './components/UrlConfigPanel';

function App() {
  const {
    state,
    startMonitoring,
    pauseMonitoring,
    stopMonitoring,
    performCheck,
    dismissAlarm,
    testAlarm,
    toggleAlarm,
    requestPushPermission,
    acknowledgeNotification,
    clearLogs,
    setIntervalSeconds,
    setConfig,
  } = useMonitor();

  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Toast on detection
  useEffect(() => {
    if (state.detectionState === 'detected' && state.alarmActive) {
      toast.custom(
        (t) => (
          <div className={`${t.visible ? 'animate-slide-in' : 'opacity-0'} max-w-md w-full bg-slate-800 border-2 border-red-500 shadow-2xl shadow-red-500/30 rounded-2xl p-4`}>
            <div className="flex items-start gap-3">
              <span className="text-3xl animate-bounce">🚨</span>
              <div className="flex-1 min-w-0">
                <p className="text-lg font-bold text-red-400">🔊 ALARM ACTIVE!</p>
                <p className="text-sm text-emerald-400 font-semibold mt-1">{state.currentPageText || 'Page Changed!'}</p>
                {state.detectedUrl && (
                  <a href={state.detectedUrl} target="_blank" rel="noopener noreferrer"
                    className="text-xs text-blue-400 mt-1 block truncate hover:text-blue-300 underline">
                    🔗 {state.detectedUrl}
                  </a>
                )}
              </div>
            </div>
          </div>
        ),
        { duration: Infinity, position: 'top-right' }
      );
    }
  }, [state.alarmActive, state.detectionState, state.detectedUrl, state.currentPageText]);

  const isRunning = state.status === 'running' || state.status === 'checking' || state.status === 'detected';

  // Truncate URL for display
  const displayUrl = (() => {
    try { const u = new URL(state.config.targetUrl); return u.hostname + u.pathname; }
    catch { return state.config.targetUrl; }
  })();

  return (
    <div className={`min-h-screen bg-dark-900 ${state.alarmActive ? 'animate-alarm-flash' : ''}`}>
      <Toaster />
      <AlarmOverlay
        active={state.alarmActive}
        detectedUrl={state.detectedUrl}
        currentPageText={state.currentPageText}
        monitoredUrl={state.config.targetUrl}
        onDismiss={dismissAlarm}
      />

      <Header status={state.status} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">

        {/* Top bar */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-4 text-sm text-slate-400">
            <span>🕐 {currentTime.toLocaleTimeString()}</span>
            <span className="hidden sm:inline">|</span>
            <span className="hidden sm:inline">📊 {state.checkCount} checks</span>
          </div>
          {state.status === 'idle' && (
            <button
              onClick={startMonitoring}
              disabled={!state.config.targetUrl}
              className="px-6 py-2.5 bg-gradient-to-r from-emerald-500 to-emerald-600 text-white font-semibold rounded-xl hover:from-emerald-400 hover:to-emerald-500 transition-all shadow-lg shadow-emerald-500/20 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              🚀 Start Monitoring
            </button>
          )}
        </div>

        {/* Detection Banner */}
        {state.detectionState === 'detected' && (
          <div className="bg-gradient-to-r from-emerald-500/20 to-emerald-600/10 border-2 border-emerald-500/40 rounded-2xl p-5 animate-pulse-glow">
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <span className="text-5xl">🎉</span>
              <div className="text-center sm:text-left flex-1 min-w-0">
                <h2 className="text-2xl font-bold text-emerald-glow">Page Changed!</h2>
                <p className="text-slate-300 mt-1">
                  <span className="font-semibold text-emerald-400">{state.currentPageText}</span>
                </p>
                {state.detectedUrl && (
                  <div className="mt-3 bg-blue-500/10 border border-blue-400/30 rounded-xl p-3">
                    <div className="text-xs text-blue-300/70 uppercase tracking-wider mb-1 font-semibold">🔗 Link found on page:</div>
                    <a href={state.detectedUrl} target="_blank" rel="noopener noreferrer"
                      className="text-blue-400 hover:text-blue-300 text-sm font-mono break-all underline underline-offset-2">
                      {state.detectedUrl}
                    </a>
                  </div>
                )}
              </div>
              <div className="flex flex-col gap-2 shrink-0">
                {state.detectedUrl && (
                  <a href={state.detectedUrl} target="_blank" rel="noopener noreferrer"
                    className="px-6 py-3 bg-blue-500 hover:bg-blue-400 text-white font-bold rounded-xl transition-colors shadow-lg text-center">
                    🔗 Open Link
                  </a>
                )}
                <a href={state.config.targetUrl} target="_blank" rel="noopener noreferrer"
                  className="px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-white font-bold rounded-xl transition-colors shadow-lg text-center">
                  Visit Page →
                </a>
              </div>
            </div>
          </div>
        )}

        {/* Stats Bar */}
        {state.status !== 'idle' && (
          <StatsBar
            checkCount={state.checkCount}
            errorCount={state.errorCount}
            startTime={state.startTime}
            status={state.status}
            consecutiveErrors={state.consecutiveErrors}
          />
        )}

        {/* Status Cards */}
        <MonitoringStatus
          status={state.status}
          detectionState={state.detectionState}
          lastChecked={state.lastChecked}
          lastDetected={state.lastDetected}
          checkCount={state.checkCount}
          errorCount={state.errorCount}
          startTime={state.startTime}
          currentPageText={state.currentPageText}
          detectedUrl={state.detectedUrl}
        />

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column */}
          <div className="space-y-6">
            {/* URL Config — top priority */}
            <UrlConfigPanel
              config={state.config}
              isRunning={isRunning}
              onSave={setConfig}
            />
            <MonitorControls
              status={state.status}
              alarmEnabled={state.alarmEnabled}
              alarmActive={state.alarmActive}
              pushEnabled={state.pushEnabled}
              intervalSeconds={state.intervalSeconds}
              onStart={startMonitoring}
              onPause={pauseMonitoring}
              onStop={stopMonitoring}
              onRefresh={performCheck}
              onTestAlarm={testAlarm}
              onToggleAlarm={toggleAlarm}
              onDismissAlarm={dismissAlarm}
              onRequestPush={requestPushPermission}
              onSetInterval={setIntervalSeconds}
            />
            <NextCheckTimer
              lastChecked={state.lastChecked}
              intervalSeconds={state.intervalSeconds}
              status={state.status}
            />
            <TargetInfo config={state.config} />
          </div>

          {/* Right Column */}
          <div className="lg:col-span-2 space-y-6">
            <LogConsole logs={state.logs} onClear={clearLogs} />
            <NotificationHistory
              notifications={state.notifications}
              onAcknowledge={acknowledgeNotification}
            />
          </div>
        </div>

        {/* Footer */}
        <footer className="text-center text-xs text-slate-600 py-6 border-t border-slate-800/50">
          <p>Rusty Iron Monitor — Real-Time Website Change Detection</p>
          <p className="mt-1">
            Monitoring{' '}
            <a href={state.config.targetUrl} target="_blank" rel="noopener noreferrer"
              className="text-slate-500 hover:text-slate-400 underline underline-offset-2">
              {displayUrl}
            </a>
            {' '}every {state.intervalSeconds}s
          </p>
        </footer>
      </main>
    </div>
  );
}

export default App;
